/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package maltcms.ui.fileHandles.properties.wizards;

import java.util.Map;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import org.openide.util.NotImplementedException;

/**
 *
 * @author mw
 */
public class HashTableModel implements TableModel {

    private Map<String, String> property;
    private String[] header = new String[]{"Key", "Value"};
    private boolean simplePropertyStyle = true;

    public HashTableModel(Map<String, String> property) {
        this.property = property;
    }

    @Override
    public int getRowCount() {
        return this.property.size() - 3;
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return header[columnIndex];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return String.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if (columnIndex == 1) {
//            String key = getValueAt(rowIndex, columnIndex - 1).toString();
//            if (!key.equals(NewPipelineElementVisualPanel1.REQUIRED_VARS)
//                    && !key.equals(NewPipelineElementVisualPanel1.OPTIONAL_VARS)
//                    && !key.equals(NewPipelineElementVisualPanel1.PROVIDED_VARS)) {
            return true;
//            }
        }
        return false;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            String key = this.property.keySet().toArray(new String[]{})[rowIndex];
            if (this.simplePropertyStyle) {
                String[] tmp = key.split("\\.");
                if (tmp.length > 0) {
                    return tmp[tmp.length - 1];
                } else {
                    return key;
                }
            } else {
                return key;
            }
        } else {
            return this.property.get(this.property.keySet().toArray(new String[]{})[rowIndex]).toString();
        }
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        if (columnIndex == 0) {
            throw new NotImplementedException("No use");
        } else {
            this.property.put(this.property.keySet().toArray(new String[]{})[rowIndex], aValue.toString());
        }
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
    }
}
