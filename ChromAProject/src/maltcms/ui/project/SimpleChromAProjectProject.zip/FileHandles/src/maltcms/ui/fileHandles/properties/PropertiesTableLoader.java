/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package maltcms.ui.fileHandles.properties;

import java.util.Map;
import java.util.Vector;
import javax.swing.table.TableModel;
import maltcms.ui.fileHandles.properties.wizards.HashTableModel;
import maltcms.ui.fileHandles.properties.wizards.PipelinePropertiesVisualPanel1;

/**
 *
 * @author mw
 */
public class PropertiesTableLoader {

    public TableModel getModel(Map<String, String> properties) {

        Vector<String> header = new Vector<String>();
        header.add("Key");
        header.add("Value");

        Vector<Vector<String>> columns = new Vector<Vector<String>>();

        for (String k : properties.keySet()) {
            if (!k.equals(PipelinePropertiesVisualPanel1.REQUIRED_VARS)
                    && !k.equals(PipelinePropertiesVisualPanel1.OPTIONAL_VARS)
                    && !k.equals(PipelinePropertiesVisualPanel1.PROVIDED_VARS)) {
                Vector<String> entry = new Vector<String>();
                entry.add(k);
                entry.add(properties.get(k));
                columns.add(entry);
            }
        }

//        return new CustomTableModel(columns, header);
        return new HashTableModel(properties);
    }
}
