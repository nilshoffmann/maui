/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package maltcms.ui.fileHandles.properties.graph;

import java.util.HashMap;
import java.util.Map;
import org.netbeans.api.visual.widget.Scene;
import org.netbeans.api.visual.widget.general.IconNodeWidget;

/**
 *
 * @author mw
 */
public class PipelineElementWidget extends IconNodeWidget {

    private Map<String, String> properties = new HashMap<String, String>();
    private Map<String, String> variables = new HashMap<String, String>();
    private String className = "";

    public PipelineElementWidget(Scene scene, TextOrientation to) {
        super(scene, to);
    }

    public PipelineElementWidget(Scene scene) {
        super(scene);
    }

    public Map<String, String> getProperties() {
        return this.properties;
    }

    public void setProperties(final Map<String, String> properties) {
        if (properties != null) {
            this.properties = properties;
        }
    }

    public boolean setPorperty(String key, String value) {
        if (!this.properties.containsKey(key)) {
            this.properties.put(key, value);
            return true;
        }
        return false;
    }

    public String getProperty(final String key) {
        if (this.properties.containsKey(key)) {
            return this.properties.get(key);
        }
        return null;
    }

    public String getClassName() {
        return this.className;
    }

    public void setClassName(String className) {
        if (className != null) {
            this.className = className;
        }
    }

    public void setVariables(Map<String, String> variables) {
        if (variables != null) {
            this.variables = variables;
        }
    }

    public Map<String, String> getVariables() {
        return this.variables;
    }

    public String getVariables(String key) {
        return this.variables.get(key);
    }
}
