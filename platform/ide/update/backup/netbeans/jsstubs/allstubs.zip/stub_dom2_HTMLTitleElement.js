var HTMLTitleElement = Object.extend(new HTMLElement(), {
  // This is just a stub for a builtin native JavaScript object.
/**
 * The script content of the element.
 * @type String
 */
text: undefined,
});

