var HTMLPreElement = Object.extend(new HTMLElement(), {
  // This is just a stub for a builtin native JavaScript object.
/**
 * Frame width. See the 
 * width attribute definition in HTML 4.01.
 * @type Number
 */
width: undefined,
});

