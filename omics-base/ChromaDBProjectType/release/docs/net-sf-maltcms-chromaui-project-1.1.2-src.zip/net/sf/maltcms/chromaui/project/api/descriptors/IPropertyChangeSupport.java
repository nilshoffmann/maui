/* 
 * Maui, Maltcms User Interface. 
 * Copyright (C) 2008-2012, The authors of Maui. All rights reserved.
 *
 * Project website: http://maltcms.sf.net
 *
 * Maui may be used under the terms of either the
 *
 * GNU Lesser General Public License (LGPL)
 * http://www.gnu.org/licenses/lgpl.html
 *
 * or the
 *
 * Eclipse Public License (EPL)
 * http://www.eclipse.org/org/documents/epl-v10.php
 *
 * As a user/recipient of Maui, you may choose which license to receive the code 
 * under. Certain files or entire directories may not be covered by this 
 * dual license, but are subject to licenses compatible to both LGPL and EPL.
 * License exceptions are explicitly declared in all relevant files or in a 
 * LICENSE file in the relevant directories.
 *
 * Maui is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. Please consult the relevant license documentation
 * for details.
 */
package net.sf.maltcms.chromaui.project.api.descriptors;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 *
 * @author Nils Hoffmann
 */
public interface IPropertyChangeSupport {

    void addPropertyChangeListener(String string, PropertyChangeListener pl);

    void addPropertyChangeListener(PropertyChangeListener pl);

    void fireIndexedPropertyChange(String string, int i, boolean bln, boolean bln1);

    void fireIndexedPropertyChange(String string, int i, int i1, int i2);

    void fireIndexedPropertyChange(String string, int i, Object o, Object o1);

    void firePropertyChange(PropertyChangeEvent pce);

    void firePropertyChange(String string, boolean bln, boolean bln1);

    void firePropertyChange(String string, int i, int i1);

    void firePropertyChange(String string, Object o, Object o1);

    PropertyChangeListener[] getPropertyChangeListeners(String string);

    PropertyChangeListener[] getPropertyChangeListeners();

    boolean hasListeners(String string);

    void removePropertyChangeListener(String string, PropertyChangeListener pl);

    void removePropertyChangeListener(PropertyChangeListener pl);
    
}
