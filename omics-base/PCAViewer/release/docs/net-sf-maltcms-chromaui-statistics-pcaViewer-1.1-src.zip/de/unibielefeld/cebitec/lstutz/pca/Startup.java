/* 
 * Maui, Maltcms User Interface. 
 * Copyright (C) 2008-2012, The authors of Maui. All rights reserved.
 *
 * Project website: http://maltcms.sf.net
 *
 * Maui may be used under the terms of either the
 *
 * GNU Lesser General Public License (LGPL)
 * http://www.gnu.org/licenses/lgpl.html
 *
 * or the
 *
 * Eclipse Public License (EPL)
 * http://www.eclipse.org/org/documents/epl-v10.php
 *
 * As a user/recipient of Maui, you may choose which license to receive the code 
 * under. Certain files or entire directories may not be covered by this 
 * dual license, but are subject to licenses compatible to both LGPL and EPL.
 * License exceptions are explicitly declared in all relevant files or in a 
 * LICENSE file in the relevant directories.
 *
 * Maui is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. Please consult the relevant license documentation
 * for details.
 */
package de.unibielefeld.cebitec.lstutz.pca;


public class Startup {
//	public static void main(String args[]){
////		System.setSecurityManager(null);
///*		if(args.length == 0){
//			System.out.println("No input file specified...");
//			System.exit(1);
//		}*/
//		//System.out.println(args[0]);
//		String name = "MeltDB 3D Viewer";
//		if(args.length==3) name = args[1];
//		String url;
//		if(args.length==2) {
//			url = args[1];
//		} else {
//			url = args[2];
//		}
//		if(args[0].equals("xml")){
//			XMLParser parser = new XMLParser(ImportUtilities.get_url_input_stream(url));
//			StandardGUI gui = new StandardGUI(name, ParserUtilities.group_data(parser.parse_data()));			
//		} else if(args[0].equals("csv")){
//			CSVParser parser = new CSVParser(ImportUtilities.get_url_input_stream(url));
//			StandardGUI gui = new StandardGUI(name, ParserUtilities.group_data(parser.parse_data()));
//		}
//		/*try {
////			InputStream in = new FileInputStream(ClassLoader.getSystemResource("dataset/meltdb.xml").getFile());
//			InputStream in = new FileInputStream(new File("C:/meltdb.xml"));
//			//CSVParser parser = new CSVParser(in);
//			XMLParser parser = new XMLParser(in);
//			StandardGUI gui = new StandardGUI(name,ParserUtilities.group_data(parser.parse_data()));
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}*/
//	}
}
